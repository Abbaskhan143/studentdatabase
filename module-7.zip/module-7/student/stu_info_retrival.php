<html>
<head>
    <title>info retrival</title>
</head>
<body>
    <form method="POST">
    <h1>student information retrival</h1>
    Rollnumber:<input type="text" name="rollno"><br><br>
    <input type="submit" value="search" name="search">
    </form>
</body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zphstbpl";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn)
 {
    die("Connection failed: " . mysqli_connect_error());
}
$eid=$_POST['rollno'];
$sql="Select * from student where $eid=rollno";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
    while($row=mysqli_fetch_assoc($result))
    {
        echo "rollno:  ".$row["rollno"]."<br>"."firstname:  ".$row["firstname"]."<br>"."lastname:  ".$row["lastname"]."<br>"."email:  ".$row["email"]."<br>";

    }

}
else{
    echo "0 results";
}
mysqli_close($conn);
?>
</html>