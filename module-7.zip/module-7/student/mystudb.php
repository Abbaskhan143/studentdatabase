<?php
$server="localhost";
$username="root";
$password="";
$dbname="zphstbpl";
$conn=mysqli_connect($server,$username,$password,$dbname);
if(!$conn)
{
	die("could not connected".mysqli_connect_error());
}
else
{
$rollno=$_POST['rollno'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$sql="insert into student values('$rollno','$firstname','$lastname','$email')";
}
if(mysqli_query($conn,$sql))
{
	echo " new record inserted successfully";
}else{
	echo "Sorry!error occured $sql".mysqli_error($conn);
}
mysqli_close($conn);
?>