<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zphstbpl";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// sql to create table
$sql = "insert into student1('rollnumber','firstname','lastname','email');

if (mysqli_query($conn, $sql)) {
  echo "one record inserted successfully";
} else {
  echo "Error inserting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>